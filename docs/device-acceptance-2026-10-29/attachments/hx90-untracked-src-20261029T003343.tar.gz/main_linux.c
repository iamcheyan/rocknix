#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include "fbsplash.h"
#include "svg_parser.h"
#include "svg_renderer.h"
#include "dt_rotation.h"

const char *svg_paths[] = {
    "M 234 140 L 270 140 L 270 324 L 364 324 L 364 360 L 234 360 Z",
    "M 414 140 L 450 140 L 450 360 L 414 360 Z",
    "M 500 140 L 536 140 L 614 290 L 614 140 L 650 140 L 650 360 L 614 360 L 536 210 L 536 360 L 500 360 Z",
    "M 700 140 L 736 140 L 736 300 C 736 324 814 324 814 300 L 814 140 L 850 140 L 850 300 C 850 360 700 360 700 300 Z",
    "M 900 140 L 936 140 L 975 203 L 1014 140 L 1050 140 L 1012 250 L 1050 360 L 1014 360 L 975 297 L 936 360 L 900 360 L 938 250 Z"
};

const char *svg_colors[] = {
    "rgb(255,255,255)",
    "rgb(255,255,255)",
    "rgb(255,255,255)",
    "rgb(255,255,255)",
    "rgb(250,204,21)"
};

#define NUM_PATHS (sizeof(svg_paths) / sizeof(svg_paths[0]))

int main(void) {
    const char *fb_device = "/dev/fb0";
    int rotation = get_display_rotation();
    if (access(fb_device, R_OK | W_OK) != 0) return 1;
    Framebuffer *fb = fb_init(fb_device);
    if (!fb) return 1;
    DisplayInfo *display_info = calculate_display_info(fb);
    if (!display_info) { fb_cleanup(fb); return 1; }
    for (uint32_t y = 0; y < fb->vinfo.yres; y++) {
        for (uint32_t x = 0; x < fb->vinfo.xres; x++) {
            set_pixel(fb, x, y, 0x00000000);
        }
    }
    for (size_t i = 0; i < NUM_PATHS; i++) {
        SVGPath *svg = parse_svg_path(svg_paths[i], svg_colors[i]);
        if (!svg) continue;
        if (rotation) rotate_svg_path(svg, rotation);
        render_svg_path(fb, svg, display_info);
        free_svg_path(svg);
    }
    fb_flush(fb);
    free(display_info);
    fb_cleanup(fb);
    return 0;
}
