#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include "fbsplash.h"
#include "dt_rotation.h"

// 7 columns x 9 rows bitmap font for 'R', 'G', '3', '4', 'X'
static const uint8_t glyph_R[9] = {
    0b1111110,
    0b1100011,
    0b1100011,
    0b1100011,
    0b1111110,
    0b1111000,
    0b1101100,
    0b1100110,
    0b1100011
};

static const uint8_t glyph_G[9] = {
    0b0111110,
    0b1100011,
    0b1100000,
    0b1100000,
    0b1101111,
    0b1100011,
    0b1100011,
    0b1100011,
    0b0111110
};

static const uint8_t glyph_3[9] = {
    0b1111110,
    0b0000011,
    0b0000011,
    0b0000110,
    0b0111100,
    0b0000011,
    0b0000011,
    0b1100011,
    0b0111110
};

static const uint8_t glyph_4[9] = {
    0b0000110,
    0b0001110,
    0b0011110,
    0b0110110,
    0b1100110,
    0b1111111,
    0b0000110,
    0b0000110,
    0b0000110
};

static const uint8_t glyph_X[9] = {
    0b1100011,
    0b1110111,
    0b0111110,
    0b0011100,
    0b0011100,
    0b0011100,
    0b0111110,
    0b1110111,
    0b1100011
};

static const uint8_t *glyphs[6] = {
    glyph_R, glyph_G, glyph_3, glyph_4, glyph_X, glyph_X
};

int main(void) {
    Framebuffer *fb = fb_init("/dev/fb0");
    if (!fb) {
        fprintf(stderr, "fb_init failed\n");
        return 1;
    }

    uint32_t w = fb->vinfo.xres;
    uint32_t h = fb->vinfo.yres;

    // Clear screen to deep retro dark background
    for (uint32_t y = 0; y < h; y++) {
        for (uint32_t x = 0; x < w; x++) {
            set_pixel(fb, x, y, 0xFF0D0E15);
        }
    }

    const int dot_size = 9;   // size of each pixel dot
    const int dot_gap  = 2;   // gap between dots
    const int step     = dot_size + dot_gap; // 11px per matrix unit
    const int glyph_w  = 7;   // columns
    const int glyph_h  = 9;   // rows
    const int glyph_spacing = 2; // units between letters
    const int num_chars = 6;

    int total_units_x = num_chars * glyph_w + (num_chars - 1) * glyph_spacing;
    int total_width_px = total_units_x * step - dot_gap;
    int total_height_px = glyph_h * step - dot_gap;

    int start_x = (w - total_width_px) / 2;
    int start_y = (h - total_height_px) / 2;

    uint32_t char_colors[6] = {
        0xFFF1F5F9, 0xFFF1F5F9, // R, G in warm retro white
        0xFFF1F5F9, 0xFFF1F5F9, // 3, 4
        0xFFF59E0B, 0xFFF59E0B  // X, X in amber/gold
    };

    int cur_unit_x = 0;
    for (int c = 0; c < num_chars; c++) {
        const uint8_t *glyph = glyphs[c];
        uint32_t color = char_colors[c];

        for (int r = 0; r < glyph_h; r++) {
            uint8_t row_bits = glyph[r];
            for (int col = 0; col < glyph_w; col++) {
                int px_start = start_x + (cur_unit_x + col) * step;
                int py_start = start_y + r * step;

                if (row_bits & (1 << (glyph_w - 1 - col))) {
                    for (int dy = 0; dy < dot_size; dy++) {
                        for (int dx = 0; dx < dot_size; dx++) {
                            uint32_t dot_color = color;
                            if (dx == dot_size - 1 || dy == dot_size - 1) {
                                uint8_t r8 = ((color >> 16) & 0xFF) * 8 / 10;
                                uint8_t g8 = ((color >> 8) & 0xFF) * 8 / 10;
                                uint8_t b8 = (color & 0xFF) * 8 / 10;
                                dot_color = (0xFF << 24) | (r8 << 16) | (g8 << 8) | b8;
                            }
                            set_pixel(fb, px_start + dx, py_start + dy, dot_color);
                        }
                    }
                } else {
                    // Unlit dot grid
                    for (int dy = 0; dy < dot_size; dy++) {
                        for (int dx = 0; dx < dot_size; dx++) {
                            set_pixel(fb, px_start + dx, py_start + dy, 0xFF181924);
                        }
                    }
                }
            }
        }
        cur_unit_x += glyph_w + glyph_spacing;
    }

    fb_flush(fb);
    fb_cleanup(fb);
    return 0;
}
