#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/fb.h>
#include <string.h>

// 7 columns x 9 rows bitmap font for 'R', 'G', '3', '4', 'X'
static const uint8_t glyph_R[9] = {
    0b1111110,
    0b1100011,
    0b1100011,
    0b1100011,
    0b1111110,
    0b1111000,
    0b1101100,
    0b1100110,
    0b1100011
};

static const uint8_t glyph_G[9] = {
    0b0111110,
    0b1100011,
    0b1100000,
    0b1100000,
    0b1101111,
    0b1100011,
    0b1100011,
    0b1100011,
    0b0111110
};

static const uint8_t glyph_3[9] = {
    0b1111110,
    0b0000011,
    0b0000011,
    0b0000110,
    0b0111100,
    0b0000011,
    0b0000011,
    0b1100011,
    0b0111110
};

static const uint8_t glyph_4[9] = {
    0b0000110,
    0b0001110,
    0b0011110,
    0b0110110,
    0b1100110,
    0b1111111,
    0b0000110,
    0b0000110,
    0b0000110
};

static const uint8_t glyph_X[9] = {
    0b1100011,
    0b1110111,
    0b0111110,
    0b0011100,
    0b0011100,
    0b0011100,
    0b0111110,
    0b1110111,
    0b1100011
};

static const uint8_t *glyphs[6] = {
    glyph_R, glyph_G, glyph_3, glyph_4, glyph_X, glyph_X
};

int main(void) {
    int fb_fd = open("/dev/fb0", O_RDWR);
    if (fb_fd < 0) {
        perror("open fb0");
        return 1;
    }

    struct fb_var_screeninfo vinfo;
    if (ioctl(fb_fd, FBIOGET_VSCREENINFO, &vinfo) < 0) {
        perror("ioctl");
        close(fb_fd);
        return 1;
    }

    size_t screensize = vinfo.yres_virtual * vinfo.xres_virtual * (vinfo.bits_per_pixel / 8);
    uint32_t *fbp = (uint32_t *)mmap(0, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, fb_fd, 0);
    if (fbp == MAP_FAILED) {
        perror("mmap");
        close(fb_fd);
        return 1;
    }

    // Clear screen to deep retro black / very dark slate
    for (size_t i = 0; i < screensize / 4; i++) {
        fbp[i] = 0xFF0A0A0C;
    }

    const int dot_size = 9;   // size of each pixel dot
    const int dot_gap  = 2;   // gap between dots
    const int step     = dot_size + dot_gap; // 11px per matrix unit
    const int glyph_w  = 7;   // columns
    const int glyph_h  = 9;   // rows
    const int glyph_spacing = 2; // units between letters
    const int num_chars = 6;

    int total_units_x = num_chars * glyph_w + (num_chars - 1) * glyph_spacing;
    int total_width_px = total_units_x * step - dot_gap;
    int total_height_px = glyph_h * step - dot_gap;

    int start_x = (vinfo.xres - total_width_px) / 2;
    int start_y = (vinfo.yres - total_height_px) / 2;

    // Dot colors:
    // RG: clean retro white (0xFFE2E8F0)
    // 34: electric amber/orange (0xFFF59E0B)
    // XX: cool neon cyan (0xFF38BDF8)
    // or all warm retro CRT white: 0xFFF1F5F9
    uint32_t char_colors[6] = {
        0xFFF1F5F9, 0xFFF1F5F9, // R, G
        0xFFF1F5F9, 0xFFF1F5F9, // 3, 4
        0xFFF59E0B, 0xFFF59E0B  // X, X in retro amber!
    };

    int cur_unit_x = 0;
    for (int c = 0; c < num_chars; c++) {
        const uint8_t *glyph = glyphs[c];
        uint32_t color = char_colors[c];

        for (int r = 0; r < glyph_h; r++) {
            uint8_t row_bits = glyph[r];
            for (int col = 0; col < glyph_w; col++) {
                if (row_bits & (1 << (glyph_w - 1 - col))) {
                    int px_start = start_x + (cur_unit_x + col) * step;
                    int py_start = start_y + r * step;

                    for (int dy = 0; dy < dot_size; dy++) {
                        for (int dx = 0; dx < dot_size; dx++) {
                            int x = px_start + dx;
                            int y = py_start + dy;
                            if (x >= 0 && x < (int)vinfo.xres && y >= 0 && y < (int)vinfo.yres) {
                                // Subtle pixel bevel: top/left slightly brighter, bottom/right slightly darker
                                uint32_t dot_color = color;
                                if (dx == 0 || dy == 0) {
                                    // slight highlight
                                    dot_color = color;
                                } else if (dx == dot_size - 1 || dy == dot_size - 1) {
                                    // slight shadow for authentic hardware LED/LCD dot matrix feel
                                    uint8_t r8 = ((color >> 16) & 0xFF) * 8 / 10;
                                    uint8_t g8 = ((color >> 8) & 0xFF) * 8 / 10;
                                    uint8_t b8 = (color & 0xFF) * 8 / 10;
                                    dot_color = (0xFF << 24) | (r8 << 16) | (g8 << 8) | b8;
                                }
                                fbp[y * vinfo.xres + x] = dot_color;
                            }
                        }
                    }
                } else {
                    // faint background matrix grid dot (authentic dot-matrix / LCD grid look!)
                    int px_start = start_x + (cur_unit_x + col) * step;
                    int py_start = start_y + r * step;
                    for (int dy = 0; dy < dot_size; dy++) {
                        for (int dx = 0; dx < dot_size; dx++) {
                            int x = px_start + dx;
                            int y = py_start + dy;
                            if (x >= 0 && x < (int)vinfo.xres && y >= 0 && y < (int)vinfo.yres) {
                                fbp[y * vinfo.xres + x] = 0xFF141419; // subtle unlit dot
                            }
                        }
                    }
                }
            }
        }
        cur_unit_x += glyph_w + glyph_spacing;
    }

    // Small retro subtitle below: "DOT MATRIX SYSTEM" in micro dots or leave clean
    munmap(fbp, screensize);
    close(fb_fd);
    return 0;
}
