# H700 本地运行与验证指南

本文区分桌面预览、ROCKNIX 用户空间容器、静态 rootfs 检查、QEMU 全系统模拟和 RG34XX 实机测试。它们覆盖的启动链不同，结果不能互相替代。

## 当前状态

截至 2026-10-27，本机 HX90 是 x86_64，安装有 `qemu-system-x86_64`、Docker Compose 和 X11/Wayland 桌面；没有 `qemu-system-aarch64`。QEMU x86_64 支持 KVM，但这只加速 x86 虚拟机，不能加速 H700 ARM64 系统。

仓库有 H700 aarch64 构建输出、内核 `build.ROCKNIX-H700.aarch64/build/linux-7.2/arch/arm64/boot/Image` 和 DDR4 镜像 `target/ROCKNIX-H700.aarch64-20261027-DDR4.img.gz`。本机检查到镜像 SHA-256 文件通过校验。当前展开的 `image/system` 中有 `/usr/bin/devexec`、使用 devexec 启动 heya 的 `heya.service`、ADB daemon 和 `098-devservices`；`system.cfg` 有 `adbd.enabled=1` 与 `adbusb.enabled=1`。这些证明构建输出含相应配置，不证明压缩镜像实际开机成功或 USB/TCP ADB 已经连接。

## 推荐的本地检查顺序

### 1. 静态 rootfs 闭包检查

在仓库根目录运行：

```sh
python3 tools/check-mini-rootfs.py build.ROCKNIX-H700.aarch64/image/system
```

成功输出：

```text
Mini rootfs entrypoints and ELF dependencies: OK (hardware/ABI testing still required)
```

该检查确认固定应用入口和运行时文件存在，并用 `readelf` 检查指定 AArch64 ELF 的解释器与动态库闭包。它不执行 ARM 程序，不启动 systemd/Sway/heya，不检查 `devexec` 的服务包装或 ADB 行为，也不证明 ABI、USB、显示、音频或硬件可用。

### 2. 桌面 heya 预览

仓库根目录的：

```sh
./run-simulator.sh
```

使用宿主机的 heya Go 源码和模拟状态运行 heya 界面。它适合检查界面和应用导航，不使用 ROCKNIX 镜像、不启动 systemd/Sway，也不运行 H700 AArch64 二进制。

### 3. ROCKNIX AMD64 用户空间桌面容器

`run-rocknix-desktop.sh` 使用从正式 ROCKNIX AMD64 构建提取出的真实 `image/system` RootFS。它不是虚拟机：Docker 容器默认运行 mock service 和 `sleep infinity`，然后在 GUI 模式下单独执行 heya；没有启动 systemd，也没有模拟 H700 内核或外设。容器只把测试 fixture 挂到 `/storage`，不会挂载真实 ROM、用户主目录或设备。

先确认存在 AMD64 构建导出的 rootfs：

```sh
test -x /path/to/amd64/image/system/usr/bin/sleep
```

然后选择当前桌面的后端：

```sh
ROCKNIX_ROOTFS=/path/to/amd64/image/system ROCKNIX_GUI=wayland ./run-rocknix-desktop.sh
```

或：

```sh
ROCKNIX_ROOTFS=/path/to/amd64/image/system ROCKNIX_GUI=x11 ./run-rocknix-desktop.sh
```

Wayland 需要当前会话 socket 可用；X11 需要 `DISPLAY`、`xauth` 和有效的 Xauthority cookie。默认 `ROCKNIX_GUI=none` 不启动界面。脚本没有承诺固定 720×480 窗口尺寸；尺寸由 heya/SDL 和显示后端决定。

目前本机只有 H700 ARM64 RootFS，没有 `.runtime/rootfs` AMD64 RootFS。因此不能把 H700 `image/system` 直接交给 x86_64 Docker 使用。桌面 runtime 文档还记录：AMD64 ROCKNIX 配方没有完整提供可运行的 XMPlayer 组件，随 H700 构建的 Love/ffmpeg 等文件为 AArch64 ELF。heya 的内置清单有 Terminal 和 Disk，不应仅凭存在 XMPlayer 独立包就推断桌面 fixture 可成功启动它。

### 4. 为什么附件中的 QEMU 命令不能直接启动

本机缺少 `qemu-system-aarch64`。安装该程序本身也不足以启动 H700 整盘镜像：

- H700 镜像面向 Allwinner H700 板卡，包含 U-Boot/ATF、H700 内核和设备树；QEMU `-M virt` 是另一种通用 ARM 虚拟硬件。
- 镜像不是普通 ext4 根分区。ROCKNIX initramfs 解析 `boot=` 和 `disk=`，从启动分区挂载 `SYSTEM` SquashFS、准备 `/storage`，再 `switch_root` 到 systemd。
- 只提供 `-kernel`、`root=/dev/vda` 和一个标为 raw 的 `.system` 文件不满足上述启动契约。仓库也没有已验证的 QEMU H700 机器模型、兼容 DTB 和启动脚本。
- `virtio-gpu` 不能模拟 H700 的 Panfrost/GPU、LCD、USB device controller、按键、电池或休眠硬件。

因此当前不提供声称可启动 H700 最终镜像的 QEMU 命令。要做 QEMU 系统测试，需要另行准备明确面向 QEMU `virt` 的 ARM64 内核、initramfs、rootfs/磁盘布局和 virtio 图形配置，并验证其与 ROCKNIX 启动脚本兼容；这条路径不能代表 RG34XX 板级行为。

## 检查 devexec 与 ADB 配置

检查构建输出：

```sh
test -x build.ROCKNIX-H700.aarch64/image/system/usr/bin/devexec
rg '^ExecStart=' build.ROCKNIX-H700.aarch64/image/system/usr/lib/systemd/system/heya.service
rg '^(adbd|adbusb)\.enabled=' build.ROCKNIX-H700.aarch64/image/system/usr/config/system/configs/system.cfg
test -x build.ROCKNIX-H700.aarch64/image/system/usr/sbin/adbd
test -x build.ROCKNIX-H700.aarch64/image/system/usr/lib/autostart/common/098-devservices
```

当前 H700 构建选项强制 `DEVELOPER_MODE=true` 和 `PROJECT_DEVELOPER_MODE=true`。heya 包配方因此安装 `/usr/bin/devexec`，并将服务入口设为：

```text
ExecStart=/usr/bin/devexec /usr/bin/heya ...
```

`devexec` 在 `/storage/dev/usr/bin/heya` 存在且是有效的普通文件时优先执行该热替换文件，否则执行系统 `/usr/bin/heya`。推送热替换文件的具体 ADB 命令、设备路径和权限需按设备实际连接状态确认；该 wrapper 的存在只证明切换机制已打包。

ADB 相关设置含义：

- `adbusb.enabled=1`：开机 devservices 请求 `usbgadget adb`，尝试启动 USB ADB gadget。
- `adbd.enabled=1`：usbgadget 在适用路径启动监听 TCP 5555 的 ADB daemon。
- USB ADB 还要求 UDC、USB device role、ConfigFS/FunctionFS 支持、数据线和主机成功枚举；静态 rootfs 检查不能验证这些条件。
- `/storage/.config/system/configs/system.cfg` 中用户已有的设置可能优先于镜像模板默认值。

## 设备验证

最终镜像的启动、Sway/systemd 服务状态、XMPlayer 窗口和 H700 USB gadget 只能在对应硬件上做有效验收。使用已确认的 RG34XX DDR4 镜像，并按仓库 `AGENTS.md` 的 TF 卡识别、卸载、整盘写入、等待 `conv=fsync` 和读回比对步骤执行。首次启动后检查：

```sh
systemctl status heya sway
journalctl -b -u heya -u sway --no-pager
test -x /usr/bin/devexec
rg '^ExecStart=' /usr/lib/systemd/system/heya.service
rocknix-services status adbusb
grep -E '^(adbd|adbusb)\.enabled=' /storage/.config/system/configs/system.cfg
pgrep -a adbd
ls /sys/class/udc
```

在主机侧确认 USB 枚举后再运行 `adb devices`。若测试 TCP ADB，确认设备网络可达后连接 `:5555`。通过 ADB 推送一个与设备 ABI 相符的测试版 heya 到 `/storage/dev/usr/bin/heya`，检查 heya.service 是否运行热替换二进制；移除覆盖文件后重启服务，确认回到系统版本。每项都应记录真实命令输出和镜像版本。

## 覆盖范围速查

| 方法 | 能验证 | 不能验证 |
|---|---|---|
| `check-mini-rootfs.py` | 固定文件存在、指定 ELF 的架构/解释器/共享库闭包 | 程序运行、ABI兼容、显示、系统启动、USB/硬件 |
| `run-simulator.sh` | heya 桌面预览与导航 | ROCKNIX RootFS、systemd、Sway、H700 ARM 程序 |
| AMD64 桌面容器 | ROCKNIX AMD64 用户空间和 host display 上的应用交互（限实际装入且架构兼容的应用） | H700 ARM64 镜像启动、板级外设和系统服务完整启动 |
| QEMU ARM64 `virt` | 为该虚拟硬件单独构建兼容系统后可测试 ARM64 guest | 现有 H700 整盘镜像直启、RG34XX 板级行为 |
| RG34XX 实机 | 最终镜像启动链、板级服务、屏幕、输入、ADB 和硬件应用路径 | 其它尚未实测的场景 |
